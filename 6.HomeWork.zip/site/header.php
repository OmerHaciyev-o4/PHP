<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link rel="stylesheet" href="css/style.css" />
    </head>
    <body>
        <div id="container">
            <header><?=$tercume["title"][$lang]?></header>
            <div id="wrapper">
                <nav>
                    <div>
                    <?php   
                        foreach($menu as $l => $x) {
                            echo '<a href="?lang='.$l.'"> '.ucfirst($l).'</a> |';
                        }
                    ?>
                    </div>
                    <ul>
                    <?php
                        foreach($menu[$lang] as $f => $m ){
                            echo '<li><a href="?page='.$f.'">'.$m.'</a></li>';
                        }
                    ?>
                    </ul>
                </nav>
                <main>
