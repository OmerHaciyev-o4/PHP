<?php
    require_once "trans.php";
    
    $lang = isset($_GET["lang"]) ? $_GET["lang"] :    
            (isset($_COOKIE['lang']) ? $_COOKIE['lang'] : "az");
    setcookie('lang', $lang, time() + (86400 * 30), "/");
    
    $page = isset($_GET["page"]) ? $_GET["page"] : "main";

    $file = "$lang/$page.php";

    include "header.php";
    include file_exists($file) ? $file : '404.php';
    include "footer.php";
?>