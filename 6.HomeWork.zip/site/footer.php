                </main>
            </div>
            <footer>Copyright &copy; 2022
            <?php
                echo (date("Y") > 2022) ? "-".date("Y") : ""; 
            ?>   
            </footer>
        </div>
    </body>
</html>