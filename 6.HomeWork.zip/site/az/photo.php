                    <h2>Foto Qalereya</h2>
                    <img style="width: 150px; float: none" src="../img/apple.webp" alt="Alma" />
                    <img style="width: 150px; float: none" src="../img/apple.webp" alt="Alma" />
                    <img style="width: 150px; float: none" src="../img/apple.webp" alt="Alma" />
                    <img style="width: 150px; float: none" src="../img/apple.webp" alt="Alma" />
                    <img style="width: 150px; float: none" src="../img/apple.webp" alt="Alma" />
                    <img style="width: 150px; float: none" src="../img/apple.webp" alt="Alma" />
                    <img style="width: 150px; float: none" src="../img/apple.webp" alt="Alma" />
                    <img style="width: 150px; float: none" src="../img/apple.webp" alt="Alma" />
                    <img style="width: 150px; float: none" src="../img/apple.webp" alt="Alma" />
                    <img style="width: 150px; float: none" src="../img/apple.webp" alt="Alma" />
                    <img style="width: 150px; float: none" src="../img/apple.webp" alt="Alma" />
                    <img style="width: 150px; float: none" src="../img/apple.webp" alt="Alma" />
