                    <h2>Связь с  нами</h2>
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3037.722948356505!2d49.851087515706176!3d40.41498796366871!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x403087fbef6b3dfb%3A0xc32b1d5765759234!2sSTEP%20Komp%C3%BCter%20Akademiyas%C4%B1%2C%20Baku!5e0!3m2!1sen!2s!4v1658571336681!5m2!1sen!2s" width="100%" height="400" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    <ul>
                        <li>Адрес: sdfhdfkjhdgkhjfg</li>
                        <li>Телефон: 8856546</li>
                        <li>E-mail: asdjhdf@gmail.com</li>
                    </ul>
