                    <h2>Фото альбом</h2>
                    <img style="width: 150px; float: none" src="../img/apple.webp" alt="Alma" />
                    <img style="width: 150px; float: none" src="../img/apple.webp" alt="Alma" />
                    <img style="width: 150px; float: none" src="../img/apple.webp" alt="Alma" />
                    <img style="width: 150px; float: none" src="../img/apple.webp" alt="Alma" />
                    <img style="width: 150px; float: none" src="../img/apple.webp" alt="Alma" />
                    <img style="width: 150px; float: none" src="../img/apple.webp" alt="Alma" />
                    <img style="width: 150px; float: none" src="../img/apple.webp" alt="Alma" />
                    <img style="width: 150px; float: none" src="../img/apple.webp" alt="Alma" />
                    <img style="width: 150px; float: none" src="../img/apple.webp" alt="Alma" />
                    <img style="width: 150px; float: none" src="../img/apple.webp" alt="Alma" />
                    <img style="width: 150px; float: none" src="../img/apple.webp" alt="Alma" />
                    <img style="width: 150px; float: none" src="../img/apple.webp" alt="Alma" />
