<?php
    $menu = [
        'az' => [
            'main' => "Ana səhifə",
            'about' => "Haqqımızda",
            'photo' => "Foto qalereya",
            'contact' => "Bizimlə əlaqə"
        ],
        'en' => [
            'main' => "Main Page",
            'about' => "About Us",
            'photo' => "Photo Gallery",
            'contact' => "Contact Us"
        ],
        'ru' => [
            'main' => "Заглавная",
            'about' => "О нас",
            'photo' => "Фото галлерея",
            'contact' => "Связь с нами"
        ]
    ];

    $tercume["title"]["az"] = "Satın başlığı";
    $tercume["title"]["en"] = "Webpage Title";
    $tercume["title"]["ru"] = "Заголовок сайта";
?>