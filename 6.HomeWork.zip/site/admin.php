<?php
    session_start();
    
    require_once "func.php";

    checkLogin();
    
    require_once "trans.php";
    $lang = isset($_REQUEST["lang"]) ? $_REQUEST["lang"] : 'az'; 
    $page = isset($_REQUEST["page"]) ? $_REQUEST["page"] : 'main';
    $file = "$lang/$page.php"; 
    
    if(isset($_REQUEST["text"]))
       file_put_contents($file,  $_REQUEST["text"]);



?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Document</title>
        <link rel="stylesheet" href="css/style.css" />
        <link rel="stylesheet" href="css/admin.css" />
    </head>
    <body>
        <header>CMS - Content Management System</header>
            <div id="wrapper">
                <nav>
                    <div>
                        <?php
                            foreach ($menu as $key => $value) {
                                $chk = $key == $lang ? 'checked' : '';
                                echo '<label><input '.$chk.' type="radio" name="lang" onclick="location.href=\'?lang='.$key.'\'" /> '.
                                    ucfirst($key).
                                '</label>';
                            }
                        ?>
                    </div>
                    <ul>
                    <?php
                        foreach ($menu[$lang] as $f => $m) {
                            echo '<li><a href="?lang='.$lang.'&page='.$f.'">'.$m.'</a></li>';
                        }
                    ?>
                    </ul>
                    <p><b>User: </b><i><?=$_SESSION['user']?></i><a href="?action=logout">(Logout)</a></p>
                </nav>
                <main>
                    <form method="GET">
                        <input type="hidden" name="lang" value="<?=$lang?>">
                        <input type="hidden" name="page" value="<?=$page?>">
                        <textarea name="text">
                            <?php include $file; ?>
                        </textarea>
                        <input type="submit" value="Ok" />
                    </form>
                </main>
            </div>
        <footer></footer>

        
        <script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
        <script>tinymce.init({selector:'textarea'});</script>
    </body>
</html>