<?php

    function getRequest($arr){
        $resultArr = [];
        $tempValue = null;

        for ($i=0; $i < count($arr); $i++) { 
            $tempValue = isset($_REQUEST[$arr[$i]]) ? $_REQUEST[$arr[$i]] : null;

            $resultArr[$arr[$i]] = $tempValue;           
        }

        return $resultArr;     
    }

    function checkLogin(){
        if(!isset($_SESSION['user']) || isset($_REQUEST["action"]) && $_REQUEST["action"] == "logout"){
            session_unset();
            session_destroy();
            header('Location: login.php');
            die();
        }
    }
?>