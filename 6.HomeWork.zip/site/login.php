<?php
    session_start();
    require_once "func.php";

    $varibales = getRequest(['user', 'pass', 'submit']);
    $message = '';

    if($varibales['submit'] !== null){
        if($varibales['user'] == '' || $varibales['pass'] == '')
            $message = 'Istifadeci adini veya parolu bosh olmaz.';
        elseif ($varibales['user'] !== 'admin' || $varibales['pass'] !== 'admin123') 
            $message = 'Istifadeci adini veya parolu duz yazin.';
        else{
            $_SESSION['user'] = $varibales['user'];
            header('Location: admin.php');
            die();
        }
    }
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/login.css">
</head>
<body>
    <header>Admin Login</header>  
    <main>
        <form method="POST">
            <input type="text" name="user" placeholder="Username">
            <input type="password" name="pass" placeholder="Password">
            <input type="submit" name="submit" value="Login">
            <p><?=$message?></p>
        </form>
    </main>
</body>
</html>